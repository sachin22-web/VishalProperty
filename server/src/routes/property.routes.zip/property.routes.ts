import { Router } from 'express';
import { verifyJWT, requireRole } from '../middleware/auth';
import {
  createProperty,
  getMyProperties,
  getPublicProperties,
  getPropertyById,
  updateProperty,
  deleteProperty,
  adminAllProperties,
  adminApprove,
  adminReject,
  adminTogglePremium,
  adminToggleVerified,
} from '../controllers/property.controller';

const router = Router();

// Public
router.get('/', getPublicProperties);
router.get('/:id', getPropertyById);

// User
router.post('/', verifyJWT, createProperty);
router.get('/my', verifyJWT, getMyProperties);
router.put('/:id', verifyJWT, updateProperty);
router.delete('/:id', verifyJWT, deleteProperty);

// Admin
router.get('/admin/all', verifyJWT, requireRole('admin'), adminAllProperties);
router.put('/admin/:id/approve', verifyJWT, requireRole('admin'), adminApprove);
router.put('/admin/:id/reject', verifyJWT, requireRole('admin'), adminReject);
router.put('/admin/:id/verify', verifyJWT, requireRole('admin'), adminToggleVerified);
router.put('/admin/:id/premium', verifyJWT, requireRole('admin'), adminTogglePremium);

export default router;
